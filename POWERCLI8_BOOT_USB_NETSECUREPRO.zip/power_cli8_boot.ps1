
Write-Host "🔁 Détection des disques..."
Start-Sleep -Seconds 1

$isoPath = "$PSScriptRoot\VM_NETSECURE_IA.iso"
$usbDriveLetter = "E:"   # 📌 Modifier selon la lettre de votre clé USB

Write-Host "🔧 Préparation de la clé USB $usbDriveLetter"
Start-Process diskpart -Wait -NoNewWindow -ArgumentList "/s diskpart_script.txt"

# Monter l’ISO
Write-Host "📦 Montage de l’ISO..."
Mount-DiskImage -ImagePath $isoPath
$volumes = Get-Volume | Where-Object { $_.DriveType -eq 'CD-ROM' }
$isoDrive = $volumes.DriveLetter + ":"

# Copie des fichiers
Write-Host "📥 Copie de l’ISO vers la clé USB..."
xcopy "$isoDrive\*" "$usbDriveLetter\" /E /H /K /Y

Write-Host "✅ Clé USB prête à booter NetSecurePro IA."
