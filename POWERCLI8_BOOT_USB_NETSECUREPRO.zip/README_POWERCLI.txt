
⚙️ Instructions pour utiliser Power_CLI8 et créer une clé USB bootable NetSecurePro IA :

1. Branchez votre clé USB
2. Ouvrez PowerShell en mode administrateur
3. Naviguez dans ce dossier et lancez :

   .\power_cli8_boot.ps1

4. Attendez la fin de la copie.
5. Démarrez votre PC depuis la clé pour lancer NetSecurePro IA.

Mot de passe IA : unlock_ai
