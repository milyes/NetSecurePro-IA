#!/bin/bash
read -sp 'Mot de passe IA : ' key
if [ "$key" = "unlock_ai" ]; then
  echo -e "\n✅ Accès IA accordé"
  bash startup_ai.sh
else
  echo -e "\n❌ Mot de passe incorrect."
fi
