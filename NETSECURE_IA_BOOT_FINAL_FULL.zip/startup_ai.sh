#!/bin/bash
echo '🚀 Démarrage de PowerShell_CL8 IA...'
xdg-open PowerShell_CL8/index.html || echo "Ouvrez PowerShell_CL8/index.html manuellement"
