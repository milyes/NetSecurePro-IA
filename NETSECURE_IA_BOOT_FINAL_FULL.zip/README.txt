
🧠 ISO Bootable – NetSecurePro IA
Créé par : Zoubirou Mohammed Ilyes (Milyes)
Modules inclus : NeoChatAI, AITerminal, AIMEDIXAL, DZROUGE
Mot de passe : unlock_ai
Bootable via USB / Machine Virtuelle
